---
name: Bug report
about: The app doesn't work, crashes, or missed a problem on your PC
labels: bug
---

**What happened?**
<!-- e.g. "My PC froze yesterday but Crash Inspector shows nothing" -->

**What did you expect?**

**Your system**
- Distro and version (e.g. Ubuntu 26.04):
- Crash Inspector version (`crash-inspector --version`):

**Report**
Click **Export** in the app (keep the shield button "hide personal info" ON), then attach
the .txt file here. In a terminal you can use: `crash-inspector --text --private > report.txt`
