---
name: False alarm
about: A harmless message is shown as a problem
labels: false-alarm
---

**The message** (copy it exactly):
```
paste here
```

**Which section was it in?** (e.g. Hardware & firmware, Other errors)

**Why do you think it's harmless?**
<!-- e.g. "appears on every boot, everything works fine", or a link explaining it -->

**Your hardware** (if relevant, e.g. motherboard, GPU, webcam model):
